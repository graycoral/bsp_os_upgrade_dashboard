﻿BSP Windows Runner — 포터블 실행 / Portable launch

1. ZIP 전체를 쓰기 가능한 로컬 폴더에 압축 해제하세요.
   Extract the entire ZIP to a writable local folder. Keep _internal beside the EXE.
2. BSP-Windows-Runner.exe 실행: 처음에는 메뉴 1(연결 설정) → 3(실행).
   Launch the EXE: first use menu 1 (connection setup), then 3 (start).
3. Runner Python/의존성 포함: 회사 PC에서 Runner용 pip/venv 설치 불필요.
   Runner Python and dependencies are included. No Runner pip/venv installation.
4. TC는 별도 Windows Python과 기존 TC 패키지를 명시적으로 지정하세요.
   TC Python must be an existing external interpreter outside this bundle.
   OpenSSH Client, fastboot, board drivers and TC packages are separate prerequisites.
5. 기존 사용자 홈의 .bsp-dashboard/windows 설정, DPAPI 토큰과 기록을 재사용합니다.
   Existing per-user settings, DPAPI token and runtime/UNKNOWN history are preserved.
   --home PATH optionally selects an existing external setup directory.
6. 종료는 Ctrl+C. 진행 중 장비 작업의 정상 종료를 기다리세요.
   Stop with Ctrl+C and wait for active hardware work to finish.

Windows Runner 포트가 겹치면: BSP-Windows-Runner.exe --port 18771
--port (--runner-port) defaults to 8771 when omitted. The override applies only
to this invocation; pass it again next time. Windows listens on 18771 while
Linux keeps its default reverse-tunnel listener on 8771; SSH maps the two ports.
No Linux configuration change is needed when only --port changes.
Windows browser port conflict: add --dashboard-port 18766 and open
http://127.0.0.1:18766 after selecting menu 3.
--remote-runner-port and --remote-dashboard-port select Linux-side ports;
pass matching values on both PCs. On Linux, menu 1 explicitly saves the new
Runner URL before menu 3. --ssh-port overrides the saved SSH port for this run.

--help shows setup options. --runner --help shows the loopback Runner options.
Actual company/board acceptance is separate from local package verification.
build-info.json records the source revision, scoped dirty state and dependency pins.
SHA256SUMS lists packaged files; the adjacent ZIP.sha256 checks the complete archive.
