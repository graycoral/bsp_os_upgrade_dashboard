﻿BSP Windows Runner — 포터블 실행 / Portable launch

1. ZIP 전체를 쓰기 가능한 로컬 폴더에 압축 해제하세요.
   Extract the entire ZIP to a writable local folder. Keep _internal beside the EXE.
2. BSP-Windows-Runner.exe 실행: 처음에는 메뉴 1(연결 설정) → 3(실행).
   다음부터 launch-run.cmd 또는 BSP-Windows-Runner.exe run을 사용하세요.
   Launch the EXE for first-use setup. Use launch-run.cmd for daily starts.
3. Runner Python/의존성 포함: 회사 PC에서 Runner용 pip/venv 설치 불필요.
   Runner Python and dependencies are included. No Runner pip/venv installation.
4. TC는 별도 Windows Python과 기존 TC 패키지를 명시적으로 지정하세요.
   TC Python must be an existing external interpreter outside this bundle.
   OpenSSH Client, fastboot, board drivers and TC packages are separate prerequisites.
5. 기존 사용자 홈의 .bsp-dashboard/windows 설정, DPAPI 토큰과 기록을 재사용합니다.
   Existing per-user settings, DPAPI token and runtime/UNKNOWN history are preserved.
   --home PATH optionally selects an existing external setup directory.
6. 종료는 Ctrl+C. 진행 중 장비 작업의 정상 종료를 기다리세요.
   Stop with Ctrl+C and wait for active hardware work to finish.

포트 확인: BSP-Windows-Runner.exe ports
포트 저장: BSP-Windows-Runner.exe ports --port 18771 --dashboard-port 18766 --remote-dashboard-port 8765 --save
설정 실행: BSP-Windows-Runner.exe run
연결 진단: BSP-Windows-Runner.exe doctor (또는 diagnose.cmd)
목록만 진단: BSP-Windows-Runner.exe doctor --only catalog --catalog-timeout 180

CLI ports override setup-ports.json; saved ports override prior defaults.
Only ports --save writes the profile. No automatic connection URL/token edits.
Windows default listener/browser: 8771/8766; Linux reverse listener/API: 8771/8766.
Match remote ports on both PCs. If the Linux reverse Runner port changes,
save its matching Runner URL explicitly through Linux setup menu 1.
SSH precedence: CLI, port profile, saved connection SSH port, then 22.
Doctor is noninteractive and does not start services or execute a TC/flash.
Its catalog request may cause the running server to make a temporary snapshot.
Transport timeouts: identity/boards 5 seconds, catalog saved value (default 100).
Doctor prints only stages, ports, elapsed time and sanitized result categories.
Exit codes: 0 success, 1 failure, 2 argument error. Launchers never pause.

Read GUIDE.md for the complete setup, startup, port and diagnosis procedure.
Unpack the whole ZIP to a local folder; do not run an EXE alone from Z:.

--help shows setup options. --runner --help shows the loopback Runner options.
Actual company/board acceptance is separate from local package verification.
build-info.json records the source revision, scoped dirty state and dependency pins.
SHA256SUMS lists packaged files; the adjacent ZIP.sha256 checks the complete archive.
