﻿BSP Windows Runner — 포터블 실행 / Portable launch

1. ZIP 전체를 쓰기 가능한 로컬 폴더에 압축 해제하세요.
   Extract the entire ZIP to a writable local folder. Keep _internal beside the EXE.
2. BSP-Windows-Runner.exe 실행: 처음에는 메뉴 1(연결 설정) → 3(실행).
   Launch the EXE: first use menu 1 (connection setup), then 3 (start).
3. Runner Python/의존성 포함: 회사 PC에서 Runner용 pip/venv 설치 불필요.
   Runner Python and dependencies are included. No Runner pip/venv installation.
4. TC는 별도 Windows Python과 기존 TC 패키지를 명시적으로 지정하세요.
   TC Python must be an existing external interpreter outside this bundle.
   OpenSSH Client, fastboot, board drivers and TC packages are separate prerequisites.
5. 기존 사용자 홈의 .bsp-dashboard/windows 설정, DPAPI 토큰과 기록을 재사용합니다.
   Existing per-user settings, DPAPI token and runtime/UNKNOWN history are preserved.
   --home PATH optionally selects an existing external setup directory.
6. 종료는 Ctrl+C. 진행 중 장비 작업의 정상 종료를 기다리세요.
   Stop with Ctrl+C and wait for active hardware work to finish.

--help shows setup options. --runner --help shows the loopback Runner options.
Actual company/board acceptance is separate from local package verification.
build-info.json records the source revision, scoped dirty state and dependency pins.
SHA256SUMS lists packaged files; the adjacent ZIP.sha256 checks the complete archive.
