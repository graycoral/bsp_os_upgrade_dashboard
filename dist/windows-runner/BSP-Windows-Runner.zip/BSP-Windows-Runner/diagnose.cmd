@echo off
setlocal
"%~dp0BSP-Windows-Runner.exe" doctor %*
exit /b %errorlevel%
