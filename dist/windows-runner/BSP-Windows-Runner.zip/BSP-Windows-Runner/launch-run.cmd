@echo off
setlocal
"%~dp0BSP-Windows-Runner.exe" run %*
exit /b %errorlevel%
