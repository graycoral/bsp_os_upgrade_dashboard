# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: gui-test.spec.ts >> GUI-UI-06 nested search sort and settings persistence
- Location: ..\..\tests\e2e\gui-test.spec.ts:271:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.gt-tree-actions').getByRole('button')
Expected: 1
Received: 2
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.gt-tree-actions').getByRole('button') with timeout 5000ms
  - waiting for locator('.gt-tree-actions').getByRole('button')
    14 × locator resolved to 2 elements
       - unexpected value "2"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - text: GUI TEST WORKSPACE
      - heading "Test 현황" [level=2] [ref=e6]
      - paragraph [ref=e7]: 테스트 선택부터 실행, 근거와 결과 확인까지
    - generic [ref=e8]: ● 실행 관리자 연결됨
  - generic [ref=e9]:
    - button "실제 연결 모드로 전환" [ref=e10] [cursor=pointer]
    - generic [ref=e11]: 보기 전환은 진행 중인 실행을 중단하지 않습니다.
  - generic [ref=e12]:
    - strong [ref=e13]: MOCK DEMO
    - generic [ref=e14]: Windows 단독 모드 · 로컬 Run 저장실제 TC·RBM은 미연동입니다. 장비와 운영 Dashboard 결과를 변경하지 않습니다.
  - button "TC 검색 패널 숨기기" [expanded] [ref=e16] [cursor=pointer]
  - generic [ref=e20]:
    - complementary [ref=e21]:
      - separator "TC 검색 패널 너비" [ref=e22]
      - generic [ref=e23]:
        - heading "Test cases" [level=3] [ref=e24]
        - generic [ref=e25]: 5개 선택
      - generic [ref=e26]:
        - generic [ref=e27]:
          - text: TC 검색
          - textbox "TC 검색" [ref=e28]:
            - /placeholder: 이름 · 경로 검색
        - generic [ref=e29]:
          - text: 유형
          - combobox "연결 유형 필터" [ref=e30]:
            - option "전체" [selected]
            - option "Single"
            - option "Dual"
      - button "트리 모두 접기" [expanded] [ref=e32] [cursor=pointer]
      - generic [ref=e34]: 5/5개 선택 · 5/5개 표시
      - group "TC 목록 정렬" [ref=e36]:
        - generic [ref=e37]:
          - generic "표시된 TC 전체 선택 / 해제" [ref=e38] [cursor=pointer]:
            - checkbox "표시된 TC 전체 선택" [checked] [ref=e39]
          - button "이름 정렬" [ref=e40] [cursor=pointer]: 이름
        - button "유형 정렬" [ref=e41] [cursor=pointer]: 유형
        - button "시간 정렬" [ref=e42] [cursor=pointer]: 시간
        - button "실행 순서로 보기" [pressed] [ref=e43] [cursor=pointer]: ↶
      - group "테스트 케이스 목록" [ref=e44]:
        - list [ref=e45]:
          - listitem [ref=e46]:
            - generic [ref=e47]:
              - checkbox "폴더 boot" [checked] [ref=e49]
              - button "boot 폴더 목록" [expanded] [ref=e50] [cursor=pointer]:
                - generic [aria-hidden] [ref=e51]: ▾
                - generic [ref=e52]: boot
                - generic [ref=e53]: 2/2
            - list [ref=e54]:
              - listitem [ref=e55]:
                - generic "boot/01_boot.py · 10s 제한" [ref=e56] [cursor=pointer]:
                  - generic [aria-hidden] [ref=e57]: ⠿
                  - checkbox "선택 01_boot" [checked] [ref=e58]
                  - generic [ref=e59]: 01_boot
                  - generic [ref=e61]: Single
                  - generic [ref=e62]: 10s
                - button "01_boot 실행 횟수 설정" [ref=e64] [cursor=pointer]
              - listitem [ref=e67]:
                - generic "boot/02_smoke.py · 10s 제한" [ref=e68] [cursor=pointer]:
                  - generic [aria-hidden] [ref=e69]: ⠿
                  - checkbox "선택 02_smoke" [checked] [ref=e70]
                  - generic [ref=e71]: 02_smoke
                  - generic [ref=e73]: Single
                  - generic [ref=e74]: 10s
                - button "02_smoke 실행 횟수 설정" [ref=e76] [cursor=pointer]
          - listitem [ref=e79]:
            - generic [ref=e80]:
              - checkbox "폴더 extra" [checked] [ref=e82]
              - button "extra 폴더 목록" [expanded] [ref=e83] [cursor=pointer]:
                - generic [aria-hidden] [ref=e84]: ▾
                - generic [ref=e85]: extra
                - generic [ref=e86]: 1/1
            - list [ref=e87]:
              - listitem [ref=e88]:
                - generic "extra/05_observation.py · 10s 제한" [ref=e89] [cursor=pointer]:
                  - generic [aria-hidden] [ref=e90]: ⠿
                  - checkbox "선택 05_observation" [checked] [ref=e91]
                  - generic [ref=e92]: 05_observation
                  - generic [ref=e94]: Single
                  - generic [ref=e95]: 10s
                - button "05_observation 실행 횟수 설정" [ref=e97] [cursor=pointer]
          - listitem [ref=e100]:
            - generic [ref=e101]:
              - checkbox "폴더 network" [checked] [ref=e103]
              - button "network 폴더 목록" [expanded] [ref=e104] [cursor=pointer]:
                - generic [aria-hidden] [ref=e105]: ▾
                - generic [ref=e106]: network
                - generic [ref=e107]: 2/2
            - list [ref=e108]:
              - listitem [ref=e109]:
                - generic [ref=e110]:
                  - checkbox "폴더 network/dual" [checked] [ref=e112]
                  - button "network/dual 폴더 목록" [expanded] [ref=e113] [cursor=pointer]:
                    - generic [aria-hidden] [ref=e114]: ▾
                    - generic [ref=e115]: dual
                    - generic [ref=e116]: 1/1
                - list [ref=e117]:
                  - listitem [ref=e118]:
                    - generic "network/dual/04_pair.py · 10s 제한" [ref=e119] [cursor=pointer]:
                      - generic [aria-hidden] [ref=e120]: ⠿
                      - checkbox "선택 04_pair" [checked] [ref=e121]
                      - generic [ref=e122]: 04_pair
                      - generic [ref=e124]: Dual
                      - generic [ref=e125]: 10s
                    - button "04_pair 실행 횟수 설정" [ref=e127] [cursor=pointer]
              - listitem [ref=e130]:
                - generic "network/03_link.py · 10s 제한" [ref=e131] [cursor=pointer]:
                  - generic [aria-hidden] [ref=e132]: ⠿
                  - checkbox "선택 03_link" [checked] [ref=e133]
                  - generic [ref=e134]: 03_link
                  - generic [ref=e136]: Single
                  - generic [ref=e137]: 10s
                - button "03_link 실행 횟수 설정" [ref=e139] [cursor=pointer]
      - paragraph [ref=e142]: 전체·폴더 선택은 검색·필터에 표시된 실행 가능한 TC에만 적용됩니다. 필터 밖 선택은 유지됩니다. 선택한 TC를 끌어 실행 순서를 바꿀 수 있으며 검색·정렬은 실행 순서를 유지합니다.
      - group [ref=e143]:
        - generic "현재 실행 순서 확인" [ref=e144] [cursor=pointer]
    - generic [ref=e146]:
      - tablist "TC 작업 화면" [ref=e147]:
        - tab "결과" [selected] [ref=e148] [cursor=pointer]
        - generic [ref=e149]:
          - generic [ref=e150]: 세션
          - combobox "Run 이력" [ref=e151]:
            - option "Run 선택" [selected]
            - option "7788d590 · COMPLETED · PASS"
            - option "26a5bf5d · COMPLETED · FAIL"
            - option "07238aef · CANCELLED · INCOMPLETE"
            - option "86ee57a3 · COMPLETED · PASS"
            - option "fe24067d · COMPLETED · PASS"
        - tab "연결 및 실행 설정" [ref=e152] [cursor=pointer]
      - tabpanel "결과" [ref=e156]:
        - region "실행 결과" [ref=e157]:
          - heading "결과" [level=3] [ref=e159]
          - generic [ref=e160]:
            - text: 아직 선택한 실행 결과가 없습니다.
            - generic [ref=e161]: 아래 실행 영역에서 시작하거나 위에서 세션을 선택하세요.
        - generic [ref=e162]:
          - heading [level=3] [ref=e163]:
            - button "실행" [expanded] [ref=e164] [cursor=pointer]:
              - generic [ref=e165]:
                - generic [ref=e166]: 실행
                - generic [ref=e167]: TC 5개 · 총 5회 예정
              - generic [aria-hidden] [ref=e168]: 접기
          - generic [ref=e172]:
            - generic [ref=e173]: TC 5개 · 전체 1회 · 총 5회 실행 · 1× · pass · demo-board-a
            - button "Preflight 검사" [ref=e174] [cursor=pointer]
            - button "▶ 테스트 시작" [disabled] [ref=e175]
```

# Test source

```ts
  174 |  await expect(page.getByLabel('선택 04_pair')).toBeChecked();
  175 |  await page.getByLabel('TC 검색',{exact:true}).fill('');
  176 |  await expect(page.getByLabel('선택 01_boot')).toBeChecked();
  177 |  await openSettings(page);
  178 |  const suitePanel=page.getByRole('button',{name:'Suite 관리',exact:true});if(await suitePanel.getAttribute('aria-expanded')==='false')await suitePanel.click();
  179 |  await page.getByLabel('Suite 이름').fill('Browser suite');
  180 |  await page.getByRole('button',{name:'Suite 저장 / 수정',exact:true}).click();
  181 |  await expect(page.getByRole('status')).toContainText('Suite를 저장');
  182 |  await openSettings(page);
  183 |  await page.getByRole('button',{name:'프로파일 저장',exact:true}).click();
  184 |  await expect(page.getByRole('status')).toContainText('연결 프로파일 저장');
  185 |  await launch(page);
  186 |  await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · PASS',{timeout:20000});
  187 |  await page.getByRole('tab',{name:'결과 리포트',exact:true}).click();
  188 |  const waiting=page.waitForEvent('download');await page.getByRole('link',{name:'JSON 다운로드',exact:true}).click();
  189 |  const download=await waiting;const report=JSON.parse(readFileSync((await download.path())!,'utf8'));
  190 |  expect(report.overall_result).toBe('PASS');expect(report.attempts).toHaveLength(5);
  191 |  const pair=report.attempts.find((a:any)=>a.tc_id.includes('dual'));
  192 |  expect(pair.resolved_command_argv.slice(-2)).toEqual(['COM3','COM4']);
  193 |  await page.screenshot({path:'../../.local-reports/gui-test/'+(standalone?'standalone':'dashboard')+'-desktop.png',fullPage:true});
  194 |  await page.setViewportSize({width:680,height:1000});
  195 |  await page.screenshot({path:'../../.local-reports/gui-test/'+(standalone?'standalone':'dashboard')+'-narrow.png',fullPage:true});
  196 |  expect(errors).toEqual([]);
  197 | });
  198 | 
  199 | test('GUI-UI-02 disconnect, reload, explicit recovery and new attempt',async({page})=>{
  200 |  await openTest(page);await launch(page,'disconnect');
  201 |  await expect(page.getByTestId('run-state')).toContainText('PAUSED',{timeout:20000});
  202 |  await page.reload();if(!standalone)await page.getByRole('navigation').getByRole('button',{name:'Test 현황',exact:true}).click();
  203 |  await expect(page.getByTestId('run-state')).toContainText('PAUSED');
  204 |  await expect(page.getByRole('button',{name:'▶ 재개',exact:true})).toBeDisabled();
  205 |  await page.getByRole('button',{name:'데모 연결 / 종료 확인',exact:true}).click();
  206 |  await page.getByRole('button',{name:'▶ 재개',exact:true}).click();
  207 |  await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · PASS',{timeout:20000});
  208 |  await page.locator('.gt-log-fold>summary').click();
  209 |  await expect(page.locator('.gt-logs')).toBeVisible();
  210 |  await expect(page.locator('.gt-logs')).toContainText('Attempt 2');
  211 | });
  212 | 
  213 | test('GUI-UI-03 pause/cancel and observer control transfer',async({page,context})=>{
  214 |  await openTest(page);await launch(page,'pass','0.2');
  215 |  await expect(page.getByTestId('run-state')).toContainText('RUNNING');
  216 |  const observer=await context.newPage();await openTest(observer);
  217 |  await expect(observer.getByText('관찰 모드',{exact:false})).toBeVisible();
  218 |  await control(observer,'제어권 요청','request-control');
  219 |  await expect(page.getByRole('button',{name:'제어권 이전 승인',exact:true})).toBeVisible();
  220 |  await control(page,'제어권 이전 승인','grant-control');
  221 |  await expect(observer.getByRole('button',{name:'Ⅱ 일시 정지',exact:true})).toBeEnabled();
  222 |  await control(observer,'Ⅱ 일시 정지','pause');
  223 |  await expect(observer.getByTestId('run-state')).toContainText('PAUSED',{timeout:20000});
  224 |  await control(observer,'■ 테스트 중단','cancel');
  225 |  await expect(observer.getByTestId('run-state')).toHaveText('CANCELLED · INCOMPLETE');
  226 |  await observer.close();
  227 | });
  228 | 
  229 | test('GUI-UI-04 FAIL continues and isolated Dashboard synchronization',async({page})=>{
  230 |  await openTest(page);
  231 |  if(!standalone){await openSettings(page);await page.getByRole('button',{name:'격리 데모 Job 준비',exact:true}).click();await expect(page.getByLabel('GUI Test Job')).not.toHaveValue('');}
  232 |  await launch(page,'fail');
  233 |  await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · FAIL',{timeout:20000});
  234 |  await expect(page.getByLabel('TC 판정 진행률')).toHaveAttribute('value','5');
  235 |  if(!standalone){await page.getByRole('tab',{name:'결과 리포트',exact:true}).click();await expect(page.getByRole('heading',{name:'판정 FAIL · 동기화 SUCCEEDED'})).toBeVisible();
  236 |   const jobId=await page.getByLabel('GUI Test Job').inputValue();const j=await (await page.request.get('/api/v1/gui-test/demo/jobs/'+jobId)).json();
  237 |   expect(j.modules.map((m:any)=>m.stages.device_test.status)).toEqual(['FAILED','SUCCEEDED']);}
  238 | });
  239 | 
  240 | test('GUI-UI-05 catalog drag invalidates Preflight and preserves completed Run',async({page})=>{
  241 |  await openTest(page);
  242 |  await expect(page.getByRole('button',{name:/(위로|아래로) 이동$/})).toHaveCount(0);
  243 |  const names=page.getByLabel('TC 실행 순서').locator('li');
  244 |  const original=await names.allTextContents();
  245 |  await page.getByRole('button',{name:'Preflight 검사',exact:true}).click();
  246 |  const start=page.getByRole('button',{name:'▶ 테스트 시작',exact:true});await expect(start).toBeEnabled();
  247 |  const last=page.locator('.gt-tree-case').filter({hasText:'04_pair'}),first=page.locator('.gt-tree-case').filter({hasText:'01_boot'});
  248 |  await last.locator('.gt-drag-handle').dragTo(first,{targetPosition:{x:40,y:6}});
  249 |  await expect(names).toHaveText(['04_pair',...original.slice(0,-1)]);await expect(start).toBeDisabled();
  250 |  const bottom=page.locator('.gt-tree-case').filter({hasText:'03_link'});
  251 |  await bottom.scrollIntoViewIfNeeded();const bounds=await bottom.boundingBox();
  252 |  expect(bounds!.y+bounds!.height).toBeLessThanOrEqual(page.viewportSize()!.height);
  253 |  // Move through the native drag threshold and across the target before releasing.
  254 |  // Scroll the full target into view before measuring; a lower-half drop can otherwise be outside the viewport.
  255 |  const handleBounds=await last.locator('.gt-drag-handle').boundingBox();
  256 |  await page.mouse.move(handleBounds!.x+handleBounds!.width/2,handleBounds!.y+handleBounds!.height/2);
  257 |  await page.mouse.down();
  258 |  await page.mouse.move(handleBounds!.x+handleBounds!.width/2+12,handleBounds!.y+handleBounds!.height/2,{steps:4});
  259 |  await page.mouse.move(bounds!.x+40,bounds!.y+bounds!.height*0.6,{steps:8});
  260 |  await page.mouse.move(bounds!.x+40,bounds!.y+bounds!.height*0.75,{steps:2});
  261 |  await page.mouse.up();
  262 |  await expect(names).toHaveText(original);
  263 |  await expect(page.getByLabel(/실행 위치/)).toHaveCount(0);
  264 |  await launch(page);await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · PASS',{timeout:20000});
  265 |  const id=await page.getByLabel('Run 이력').inputValue();
  266 |  const snapshot=await (await page.request.get('/api/v1/gui-test/runs/'+id)).json();expect(snapshot.tests.map((t:any)=>t.name)).toEqual(original);
  267 |  await last.locator('.gt-drag-handle').dragTo(first,{targetPosition:{x:40,y:6}});
  268 |  const after=await (await page.request.get('/api/v1/gui-test/runs/'+id)).json();expect(after.tests).toEqual(snapshot.tests);
  269 | });
  270 | 
  271 | test('GUI-UI-06 nested search sort and settings persistence',async({page})=>{
  272 |  await openTest(page);
  273 |  const treeToggle=page.locator('.gt-tree-actions').getByRole('button');
> 274 |  await expect(treeToggle).toHaveCount(1);
      |                           ^ Error: expect(locator).toHaveCount(expected) failed
  275 |  await expect(treeToggle).toBeVisible();await expect(treeToggle.locator('svg')).toHaveCount(1);
  276 |  await expect(treeToggle).toHaveText('');
  277 |  const bounds=await treeToggle.boundingBox();
  278 |  expect(bounds!.width).toBeGreaterThanOrEqual(28);expect(bounds!.height).toBeGreaterThanOrEqual(28);
  279 |  expect(bounds!.width).toBeLessThanOrEqual(32);expect(bounds!.height).toBeLessThanOrEqual(32);
  280 |  const folders=page.locator('.gt-case-group > .gt-folder-head > button');
  281 |  const network=page.locator('.gt-case-group').filter({has:page.getByRole('button',{name:'network 폴더 목록',exact:true})}).first();
  282 |  const order=await page.getByLabel('TC 실행 순서').locator('li').allTextContents();
  283 |  async function expectTreeToggle(expanded:boolean){
  284 |   const name=expanded?'트리 모두 접기':'트리 모두 펼치기';
  285 |   await expect(treeToggle).toHaveAccessibleName(name);await expect(treeToggle).toHaveAttribute('title',name);
  286 |   await expect(treeToggle).toHaveAttribute('aria-expanded',String(expanded));
  287 |   await expect(treeToggle.locator('svg path')).toHaveAttribute('d',expanded?'M5 12h14':'M12 5v14M5 12h14');
  288 |  }
  289 |  async function expectAllFolders(expanded:boolean){
  290 |   for(const folder of await folders.all())await expect(folder).toHaveAttribute('aria-expanded',String(expanded));
  291 |  }
  292 |  await expectTreeToggle(true);await expectAllFolders(true);
  293 |  await expect(network.getByRole('button',{name:'network/dual 폴더 목록',exact:true})).toBeVisible();
  294 |  await treeToggle.click();await expectTreeToggle(false);await expectAllFolders(false);
  295 |  await treeToggle.focus();await page.keyboard.press('Enter');
  296 |  await expectTreeToggle(true);await expectAllFolders(true);
  297 |  await treeToggle.click();await expectTreeToggle(false);
  298 |  await treeToggle.focus();await page.keyboard.press('Space');
  299 |  await expectTreeToggle(true);await expectAllFolders(true);
  300 |  await page.getByRole('button',{name:'network 폴더 목록',exact:true}).click();
  301 |  await expectTreeToggle(false);
  302 |  await expect(page.getByRole('button',{name:'boot 폴더 목록',exact:true})).toHaveAttribute('aria-expanded','true');
  303 |  await treeToggle.click();await expectTreeToggle(true);await expectAllFolders(true);
  304 |  await page.getByLabel('TC 검색',{exact:true}).fill('no-such-test-case');
  305 |  await expect(folders).toHaveCount(0);await expectTreeToggle(false);await expect(treeToggle).toBeDisabled();
  306 |  await expect(page.getByLabel('TC 실행 순서').locator('li')).toHaveText(order);
  307 |  await page.getByLabel('TC 검색',{exact:true}).fill('');
  308 |  await expectTreeToggle(true);await expectAllFolders(true);
  309 |  await expect(page.getByLabel('TC 실행 순서').locator('li')).toHaveText(order);
  310 |  await page.getByRole('button',{name:'이름 정렬',exact:true}).click();
  311 |  await page.getByRole('button',{name:'이름 정렬',exact:true}).click();
  312 |  const boot=page.locator('.gt-case-group').filter({has:page.getByRole('button',{name:'boot 폴더 목록',exact:true})});
  313 |  await expect(boot.locator('.gt-tc-name')).toHaveText(['02_smoke','01_boot']);
  314 |  await page.getByRole('button',{name:'트리 모두 접기',exact:true}).click();
  315 |  await page.getByLabel('TC 검색',{exact:true}).fill('network/dual');await expect(page.getByLabel('선택 04_pair')).toBeVisible();
  316 |  await page.getByLabel('폴더 network', {exact:true}).uncheck();
  317 |  await page.getByLabel('TC 검색',{exact:true}).fill('');await expect(page.getByLabel('선택 03_link')).toBeChecked();
  318 |  await page.getByLabel('선택 04_pair').check();
  319 |  await expect(page.getByLabel('TC 실행 순서').locator('li')).toHaveText(order);
  320 |  await openSettings(page);
  321 |  // REG-0039: tree icon sizing must not constrain the settings text actions.
  322 |  for(const name of ['설정 모두 접기','설정 모두 펼치기']){
  323 |   const control=page.getByRole('button',{name,exact:true});
  324 |   await expect(control).toBeVisible();await expect(control).toHaveText(name);
  325 |   const dimensions=await control.evaluate(element=>({width:element.clientWidth,scrollWidth:element.scrollWidth,height:element.clientHeight,scrollHeight:element.scrollHeight}));
  326 |   expect(dimensions.scrollWidth,`${name} horizontal clipping`).toBeLessThanOrEqual(dimensions.width+1);
  327 |   expect(dimensions.scrollHeight,`${name} vertical clipping`).toBeLessThanOrEqual(dimensions.height+1);
  328 |  }
  329 |  const suitePanel=page.getByRole('button',{name:'Suite 관리',exact:true});if(await suitePanel.getAttribute('aria-expanded')==='false')await suitePanel.click();
  330 |  await page.getByLabel('Suite 이름').fill('Preserved input');
  331 |  await page.getByRole('button',{name:'설정 모두 접기',exact:true}).click();
  332 |  await expect(page.getByLabel('Suite 이름')).toBeHidden();await expect(page.getByLabel('선택 01_boot')).toBeVisible();
  333 |  await page.getByRole('button',{name:'설정 모두 펼치기',exact:true}).click();await expect(page.getByLabel('Suite 이름')).toHaveValue('Preserved input');
  334 |  await page.getByRole('button',{name:'설정 모두 접기',exact:true}).click();await page.reload();
  335 |  if(!standalone)await page.getByRole('navigation').getByRole('button',{name:'Test 현황',exact:true}).click();
  336 |  await page.getByRole('tab',{name:'연결 및 실행 설정',exact:true}).click();
  337 |  await expect(page.getByRole('button',{name:'연결 및 실행 준비',exact:true})).toHaveAttribute('aria-expanded','false');
  338 |  await page.setViewportSize({width:375,height:900});
  339 |  await expect(page.getByLabel('TC 검색',{exact:true})).toBeVisible();
  340 |  expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(375);
  341 | });
  342 | 
  343 | test('GUI-UI-07 failed TC only rerun retains original and displays usage',async({page})=>{
  344 |  await openTest(page);await launch(page,'fail');await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · FAIL',{timeout:20000});
  345 |  const id=await page.getByLabel('Run 이력').inputValue();
  346 |  const original=await (await page.request.get('/api/v1/gui-test/runs/'+id)).json();
  347 |  const failed=original.tests.find((t:any)=>original.results[t.id]==='FAIL');
  348 |  const retry=page.getByRole('button',{name:failed.name+' 재실행',exact:true});
  349 |  await expect(retry).toHaveText('Retry');await expect(retry.locator('..')).toContainText('FAIL');
  350 |  await expect(page.getByRole('columnheader',{name:'재실행',exact:true})).toHaveCount(0);
  351 |  await retry.click();
  352 |  await expect(page.getByLabel('Run 이력')).not.toHaveValue(id);await expect(page.getByTestId('run-state')).toHaveText('COMPLETED · PASS',{timeout:20000});
  353 |  const childId=await page.getByLabel('Run 이력').inputValue();
  354 |  const child=await (await page.request.get('/api/v1/gui-test/runs/'+childId)).json();
  355 |  expect(child.parent_run_id).toBe(id);expect(child.tests.map((t:any)=>t.id)).toEqual([failed.id]);expect(child.link).toBeNull();
  356 |  const after=await (await page.request.get('/api/v1/gui-test/runs/'+id)).json();expect(after.results).toEqual(original.results);expect(after.attempts).toEqual(original.attempts);
  357 |  await expect(page.getByLabel('진행 요약',{exact:true})).toContainText('모델 호출 없음');
  358 |  const usage=page.locator('.gt-usage').first();await expect(usage).not.toHaveAttribute('open','');
  359 |  await usage.locator('summary').click();await expect(usage).toContainText('모델 호출 없음');
  360 | });
  361 | 
  362 | test('GUI-UI-08 catalog hide and resize persist without clearing selections',async({page})=>{
  363 |  await openTest(page);
  364 |  const handle=page.getByRole('separator',{name:'TC 검색 패널 너비'});
  365 |  const before=Number(await handle.getAttribute('aria-valuenow'));
  366 |  await handle.focus();await page.keyboard.press('ArrowRight');await expect(handle).toHaveAttribute('aria-valuenow',String(before+20));
  367 |  const bounds=await handle.boundingBox();await page.mouse.move(bounds!.x+4,bounds!.y+50);await page.mouse.down();await page.mouse.move(bounds!.x+64,bounds!.y+50);await page.mouse.up();
  368 |  expect(Number(await handle.getAttribute('aria-valuenow'))).toBeGreaterThan(before+20);
  369 |  await page.getByRole('button',{name:'TC 검색 패널 숨기기',exact:true}).click();await expect(page.getByLabel('TC 검색',{exact:true})).toBeHidden();
  370 |  await page.reload();if(!standalone)await page.getByRole('navigation').getByRole('button',{name:'Test 현황',exact:true}).click();
  371 |  await expect(page.getByLabel('TC 검색',{exact:true})).toBeHidden();await page.getByRole('button',{name:'TC 검색 패널 보이기',exact:true}).click();await expect(page.getByLabel('선택 04_pair')).toBeChecked();
  372 |  expect(Number(await handle.getAttribute('aria-valuenow'))).toBeGreaterThan(before+20);
  373 | });
  374 | 
```